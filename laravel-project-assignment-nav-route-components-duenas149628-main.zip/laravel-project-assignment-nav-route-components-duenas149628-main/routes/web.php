Route::get('/', function () {
    return view('welcome');
}); or Route::view('/', 'welcome');

##both routes above works but view works only for static webpages.

Route::get('/about', function () {
    return view('about');
});

Route::get('/contact', function () {
    return view('contact');
});


...